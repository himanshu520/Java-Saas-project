package com.YouTubeTools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YouTubeToolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(YouTubeToolsApplication.class, args);
	}

}
